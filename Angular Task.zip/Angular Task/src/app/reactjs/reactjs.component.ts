import { HttpErrorResponse } from "@angular/common/http";
import { Component } from "@angular/core";
import { ReactJSService } from './reactjs.service';

@Component({
    selector: 'Reactjs',
    templateUrl: "./reactjs.component.html"
})
export class ReactJSComponent{
    private result: any;
    constructor(private service: ReactJSService){}
    ngOnInit(){
        this.service.getReactJS().subscribe((posRes)=>{
            this.result = posRes;
        },(errRes: HttpErrorResponse)=>{
            console.log(errRes);
        });
    };
};