import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ReactJSComponent } from "./reactjs.component";
import { ReactJSService } from "./reactjs.service";


export const appRoutes:Routes = [
    {path:"",component:ReactJSComponent}
];

@NgModule({
    declarations:[ReactJSComponent],
    imports:[CommonModule, HttpClientModule, RouterModule.forChild(appRoutes)],
    providers:[ReactJSService],
    exports:[ReactJSComponent]
})
export class ReactJSModule{}