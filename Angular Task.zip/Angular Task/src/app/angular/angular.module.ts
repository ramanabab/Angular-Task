import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { AngularComponent } from "./angular.component";
import { AngularService } from "./angular.service";
import { Routes,RouterModule } from "@angular/router";
export const appRoutes:Routes = [
    {path:"",component:AngularComponent}
];
@NgModule({
    declarations:[AngularComponent],
    imports:[CommonModule,
             HttpClientModule,
             RouterModule.forChild(appRoutes)],
    providers:[AngularService],
    exports:[AngularComponent]
})
export class AngularModule{}
