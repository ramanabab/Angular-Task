import { Component } from "@angular/core";
import { AngularService } from './angular.service';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
    selector:"angular",
    templateUrl:"./angular.component.html"
})
export class AngularComponent{
    private result:any;
    constructor(private service:AngularService){}
    ngOnInit(){
        this.service.getAngularTopics()
                                .subscribe((posRes)=>{
            this.result = posRes;
        },(errRes:HttpErrorResponse)=>{
            if(errRes.error instanceof Error)
                console.log("client side error");
            else
                console.log("server side error");
        });
    }
};