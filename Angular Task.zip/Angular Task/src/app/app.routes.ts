import { ModuleWithProviders } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AngularModule } from "./angular/angular.module";
import { NodeJSModule } from "./nodejs/nodejs.module";
import { authGuard } from "./reactjs/auth.guard";

export const appRoutes:Routes = [
    {path:"angular",loadChildren:"./angular/angular.module#AngularModule"},
    
    {path:"nodejs",loadChildren:"./nodejs/nodejs.module#NodeJSModule"},

    {path:"reactjs", loadChildren:"./reactjs/reactjs.module#ReactJSModule", canLoad:[authGuard]}
    
   
];

export const lazyRoutes: ModuleWithProviders = RouterModule.forRoot(appRoutes);