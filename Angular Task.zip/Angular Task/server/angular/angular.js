//import express module
let express = require("express");
//import mysql module
let mysql = require("mysql");
//create the connection object
let connection = mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "root",
    database : "testdb"
});
//connect to database
connection.connect();
//export the module
module.exports = express.Router().get("/",(req,res)=>{
    connection.query(`select * from angular`,
                (err,records,fields)=>{
        if(err)
            throw err;
        else
            res.send(records);
    });
});